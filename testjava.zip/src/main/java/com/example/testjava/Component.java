package com.example.testjava;

public class Component {
	private int id;
	private int f_id;
	private String name;
	
	
	public Component(int id, int f_id, String name) {
		super();
		this.id = id;
		this.f_id = f_id;
		this.name = name;
	}
	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Component(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	

}
