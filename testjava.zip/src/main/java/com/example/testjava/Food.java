package com.example.testjava;

public class Food {
	private int id;
	private int employer;
	private String name;
	private int price;
	private int component_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEmployer() {
		return employer;
	}
	public void setEmployer(int employer) {
		this.employer = employer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getComponent_id() {
		return component_id;
	}
	public void setComponent_id(int component_id) {
		this.component_id = component_id;
	}
	public Food(int id, int employer, String name, int price, int component_id) {
		super();
		this.id = id;
		this.employer = employer;
		this.name = name;
		this.price = price;
		this.component_id = component_id;
	}
	
	
	

}
