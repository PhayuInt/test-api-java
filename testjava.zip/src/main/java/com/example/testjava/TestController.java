package com.example.testjava;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	
	private List<Food> foods = new ArrayList<>();
	private List<Component> components = new ArrayList<>();
	
	private List<Order> oeder = new ArrayList<>();
	
	
	private List<Customer> customer = new ArrayList<>();
	
	
	private final AtomicLong couter = new AtomicLong();

	
	public TestController() {
		foods.add(new Food(1,1,"ไก่ทอด",50,1));
		foods.add(new Food(2,1,"ต้มยำกุ้ง",40,2));
		
		components.add(new Component(1, 1, "ไก่"));
	
		components.add(new Component(4, 2, "กุ้ง"));
		
		oeder.add(new Order(1 , 1, 1, 2, "atm" , 1));
			
	}
	
	@GetMapping("/food")
	public List<Food> getFoods() {
		return foods;
	}
	
	@GetMapping("/food/{id}")
	public Food getFoodById(@PathVariable() int id) {
		return foods.stream().filter(result -> result.getId() == id)
				.findFirst().orElseGet(() -> null);

	}
	
	@GetMapping("/food/detail/{id}")
	public Component getFoodDetailById(@PathVariable() int id) {		
		return components.stream().filter(result -> result.getF_id() == id)
				.findFirst().orElseGet(() -> null);

	}
	
	
	
	
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping("/customer")
	public void addCustomer(@RequestBody Customer req) {
		customer.add(new Customer((couter.getAndIncrement() + 1), req.getEmail(),req.getPassword(), req.getName(), req.getAge()));
		
		
	}
	
	 
	@ResponseStatus(HttpStatus.CREATED)
	@GetMapping("/customer/{id}")
	public Customer getCustomerById(@PathVariable() int id) {
		return customer.stream().filter(result -> result.getId() == id)
				.findFirst().orElseGet(() -> null);

	}
	
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping("/order")
	public void addOrder(@RequestBody Order req) {
		oeder.add(new Order((couter.getAndIncrement() + 1) , req.getCustomer_id(), req.getStatus(),  req.getF_id(),  req.getPayment_type() ,req.getIs_paid()));

	}
	
	@ResponseStatus(HttpStatus.CREATED)
	@GetMapping("/order/{id}")
	public Order getOrderById(@PathVariable() int id) {
		return oeder.stream().filter(result -> result.getCustomer_id() == id)
				.findAny().orElseGet(() -> null);

	}
	
	@PutMapping("/order/{userId}")
	public void cancelOrder(@RequestBody Order req, @PathVariable() long userId) {
		oeder.stream().filter(result -> result.getCustomer_id() == userId ).filter(result -> result.getId() == req.getId())
		.findFirst()
		.ifPresentOrElse(result -> {
			result.setStatus(req.getStatus());
		}, () -> {});
	}
	
	
	
	


}
