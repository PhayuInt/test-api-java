package com.example.testjava;

public class Order {
	private long id;
	private int customer_id;
	private int status; // 0 ยังไม่ยินยัน 1 = ยินยัน 2 = ยกเลิก
	private int f_id; //food id
	private String payment_type;
	private int is_paid; // 0 = ยังไม่่จ่าย 1 = จ่าย
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public String getPayment_type() {
		return payment_type;
	}
	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}
	public int getIs_paid() {
		return is_paid;
	}
	public void setIs_paid(int is_paid) {
		this.is_paid = is_paid;
	}
	public Order(long id, int customer_id, int status, int f_id, String payment_type, int is_paid) {
		super();
		this.id = id;
		this.customer_id = customer_id;
		this.status = status;
		this.f_id = f_id;
		this.payment_type = payment_type;
		this.is_paid = is_paid;
	}
	
	
	
	
	
	
	
	
	

	

}
